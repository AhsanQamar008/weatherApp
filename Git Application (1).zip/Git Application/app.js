const input = document.getElementById("userName");
const cardDiv = document.getElementById("cardDiv");

const fetchApi = async () => {
    try {
        // Ensure that the input value is not empty
        if (!input.value.trim()) {
            cardDiv.innerHTML = '';
            return; // Stop further execution if input is empty
        }

        let gitApi = await fetch(`https://api.github.com/users/${input.value}`);
        let response = await gitApi.json();

        const divContent = `
            <div class="container__bottom card-animated">
                <div class="wrapper">
                    <div class="left">
                        <img class="prof" src="${response.avatar_url}" alt="git" />
                    </div>
                    <div class="right">
                        <div class="right__top">
                            <div class="heading">
                                <h1 id="username">${response.name === null ? response.login : response.name}</h1>
                                <p id="handle">@${response.login}</p>
                                <p id="date">Joined ${response.created_at}</p>
                            </div>
                        </div>
                        <div class="desc">
                            ${!response.bio ? "N/A" : response.bio}
                        </div>
                        <div class="repos-holder">
                            <div class="item">
                                <p>Repos</p>
                                <p id="num_repos">${response.public_repos}</p>
                            </div>
                            <div class="item">
                                <p>Followers</p>
                                <p id="num-followers">${response.followers}</p>
                            </div>
                            <div class="item">
                                <p>Following</p>
                                <p id="num-following">${response.following}</p>
                            </div>
                        </div>
                        <div class="contact-holder">
                            <ul>
                                <li>
                                    <img src="./assets/icon-location.svg" alt="location" />
                                    <span id="location">${response.location}</span>
                                </li>
                                <li>
                                    <img src="./assets/icon-twitter.svg" alt="twitter" />
                                    <span id="twitter">${response.twitter_username}</span>
                                </li>
                                <li>
                                    <img src="./assets/icon-website.svg" alt="website" />
                                    <a id="web" href=${response.blog}>https://github.blog</a>
                                </li>
                                <li>
                                    <img src="./assets/icon-company.svg" alt="work" />
                                    <span id="work">@Github</span>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        `;

        // Insert user data into the cardDiv
        cardDiv.innerHTML = response.status !== "404" ? divContent : "There was an error fetching the user data. Please try again later.";
        console.log(response);

        // Reset the animation by removing and adding the class again
        const containerBottom = document.querySelector(".container__bottom");
        const containerTop = document.querySelector(".container__middle");

        // Remove the animation class to reset it
        containerTop.classList.remove("card-animated");
        containerBottom.classList.remove("card-animated");

        // Trigger reflow to restart animation
        void containerBottom.offsetWidth;

        // Add the animation class again
        containerBottom.classList.add("card-animated");
        containerTop.classList.add("card-animated");

    } catch (err) {
        console.log(err.message);
        cardDiv.innerHTML = `<p>There was an error fetching the user data. Please try again later.</p>`;
    }
};

// Event listener to trigger fetch on "Enter" key press
input.addEventListener("keypress", (event) => {
    if (event.key === "Enter") {
        fetchApi();
    }
});

// Event listener to clear cardDiv content if the input is empty
input.addEventListener("input", () => {
    if (!input.value.trim()) {
        cardDiv.innerHTML = '';  // Clear the displayed card when the input is empty
    }
});
